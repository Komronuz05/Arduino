# Home Page Playground

A Pen created on CodePen.io. Original URL: [https://codepen.io/icomgroup/pen/poMbVzG](https://codepen.io/icomgroup/pen/poMbVzG).

